// gnc_forecast_core.hpp
//
// C++ port of the numeric core of LLM_EKF_Based_Predictor1.m
// (Part 2-3 technical extractors, the adaptive EKF + RTS smoother, and
// the fractal swing-pivot support/resistance detector).
//
// Deliberately EXCLUDED from this port (see accompanying notes / chat):
//   - Tiingo / news ingestion (websave, webread) -> networking, not codegen-able
//   - LLM sentiment scoring via the Anthropic API   -> networking, not codegen-able
//   - readtable / timetable / retime                -> MATLAB-only data containers
//   - trainNetwork / bilstmLayer / predict           -> training must stay in MATLAB;
//                                                       inference-only CAN be
//                                                       code-generated separately via
//                                                       MATLAB Coder's Deep Learning
//                                                       Toolbox support, but that's a
//                                                       distinct pipeline from this file
//   - figure / subplot / yline / uitable             -> plotting/UI, not codegen-able
//
// Everything below is pure numeric std::vector<double> in, std::vector<double>
// (or small structs) out -- no MATLAB-only constructs -- so it is a faithful,
// drop-in-testable port of the parts of the pipeline that MATLAB Coder (codegen)
// could also auto-generate from the original .m functions almost unchanged.

#pragma once
#include <vector>
#include <string>

namespace gnc_forecast {

// ---------------------------------------------------------------------------
// Basic rolling-window helpers (mirror MATLAB movmean/movmin/movmax with the
// default 'Endpoints','shrink' behavior: window truncates near index 0
// instead of looking ahead or padding with NaN).
// ---------------------------------------------------------------------------
std::vector<double> trailingMovMean(const std::vector<double>& x, int window);
std::vector<double> trailingMovMin(const std::vector<double>& x, int window);
std::vector<double> trailingMovMax(const std::vector<double>& x, int window);

// ---------------------------------------------------------------------------
// Technical extractors (Part 2 in the .m file)
// ---------------------------------------------------------------------------
std::vector<double> dailyTrueRange(const std::vector<double>& high,
                                    const std::vector<double>& low,
                                    const std::vector<double>& close);

// 14-bar ATR-style rolling mean of true range (trailing window, size atrWindow)
std::vector<double> averageTrueRange(const std::vector<double>& high,
                                      const std::vector<double>& low,
                                      const std::vector<double>& close,
                                      int atrWindow = 14);

// Wilder-style RSI using trailing simple moving averages of gains/losses,
// matching the .m file's movmean-based approximation (not true Wilder EMA).
std::vector<double> relativeStrengthIndex(const std::vector<double>& close,
                                           int window = 14);

// NOTE: the .m file's "ema12"/"ema26" are misnamed -- they are actually
// trailing simple moving averages (movmean), not exponential moving
// averages. This port reproduces the ACTUAL behavior for numerical parity;
// see macdSimple() below.
struct MacdResult {
    std::vector<double> macdLine;
    std::vector<double> signalLine;
};
MacdResult macdSimple(const std::vector<double>& close,
                      int fastWindow = 12, int slowWindow = 26, int signalWindow = 9);

// Parkinson (high-low) volatility estimator, trailing 20-bar window.
std::vector<double> parkinsonVolatility(const std::vector<double>& high,
                                        const std::vector<double>& low,
                                        int window = 20);

// ---------------------------------------------------------------------------
// Adaptive asymmetric EKF + backward RTS smoother (Part 3 in the .m file)
// State = [price; velocity]. Velocity is damped (momentum-exhaustion) when
// price is falling inside the bottom 25% of its own trailing 1yr range.
// ---------------------------------------------------------------------------
struct EkfSmoothResult {
    std::vector<double> smoothedPrice;     // EKF_TruePrice
    std::vector<double> smoothedVelocity;  // EKF_Velocity
    std::vector<double> residual;          // close - smoothedPrice
};

EkfSmoothResult runAdaptiveEkfSmoother(const std::vector<double>& close,
                                       const std::vector<double>& volume,
                                       const std::vector<double>& dailyTR,
                                       int lookbackRangeDays = 252);

// ---------------------------------------------------------------------------
// Fractal swing-pivot support/resistance detector (the enhancement added on
// top of the original .m file).
// ---------------------------------------------------------------------------
struct SupportResistanceResult {
    double resistanceLevel;
    double supportLevel;
    int    resistanceStrength;   // touch count in the merged cluster
    int    supportStrength;
};

SupportResistanceResult computeSupportResistance(const std::vector<double>& high,
                                                 const std::vector<double>& low,
                                                 double currentPrice,
                                                 double recentAtr,
                                                 int lookbackRangeDays = 252,
                                                 int fractalArm = 3);

}  // namespace gnc_forecast
