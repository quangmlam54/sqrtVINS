# C++ port of the LLM_EKF_Based_Predictor1.m numeric core

## What's here (Tier 1 — ported)

| MATLAB (`LLM_EKF_Based_Predictor1.m`)                     | C++ (`gnc_forecast_core.*`)          |
|------------------------------------------------------------|---------------------------------------|
| `dailyTrueRange` computation                                | `dailyTrueRange()`                    |
| `recentATR` / ATR-style `movmean`                           | `averageTrueRange()`                  |
| `rsiCalculated`                                              | `relativeStrengthIndex()`             |
| `ema12`/`ema26`/`macdLine`/`signalLine`                     | `macdSimple()` *(see note below)*     |
| `ParkinsonVol`                                               | `parkinsonVolatility()`               |
| Forward EKF loop + backward RTS smoother (Part 3)            | `runAdaptiveEkfSmoother()`            |
| `computeSupportResistance` / `nearestClusteredLevel` (added) | `computeSupportResistance()`          |

**Note on MACD naming:** the original `.m` file's `ema12`/`ema26` are computed
with `movmean` (simple moving average with shrinking edges), not a true
exponential moving average, despite the variable names. `macdSimple()`
reproduces that *actual* behavior for numerical parity with your existing
outputs. If you want a true EMA-based MACD instead, that's a small, separate
change on both sides — say the word and I'll do both.

Verified: builds clean with `g++ -std=c++17 -Wall -Wextra` (zero warnings)
and runs correctly on synthetic data in this sandbox. `demo_main.cpp` will
also parse your real `<TICKER>_Tiingo_cache.csv` directly if you pass its
path as `argv[1]` — same column schema Tiingo already writes.

## Build

**VS Code / CMake Tools:** open this folder, `Ctrl+Shift+P` → "CMake: Configure",
then "CMake: Build" (`.vscode/tasks.json` and `c_cpp_properties.json` are
already set up for IntelliSense + build/run tasks bound to the default build
key).

**Plain Makefile** (no CMake needed): `make && ./gnc_forecast_demo`

## Live mode: `gnc_forecast_live` (no CSV needed)

`interactive_main.cpp` builds a second binary that prompts for a ticker
interactively and fetches its OHLCV history directly from the Tiingo
REST API via `libcurl`, parses it with `nlohmann/json`, and runs the
exact same numeric core as `demo_main.cpp` — no local CSV file required.

**Install the two extra dependencies** (only needed for this target;
`gnc_forecast_demo` above builds fine without them):
```bash
sudo apt-get install libcurl4-openssl-dev nlohmann-json3-dev
```
(In a Codespace/devcontainer running as root, drop `sudo`.)

**Build and run:**
```bash
cmake -B build && cmake --build build      # or: make
export TIINGO_API_KEY="your_tiingo_key_here"   # same key your .m script's `apiKey` uses
./build/gnc_forecast_live                  # or ./gnc_forecast_live with the Makefile
```
```
GNC Forecast Core -- live Tiingo mode
Enter a stock ticker (e.g. AAPL), or 'quit' to exit.

Symbol> FISV
Fetching FISV from Tiingo...

=== FISV -- live Tiingo data, 347 bars ===
Current price:          $56.32
...
Symbol> quit
Goodbye.
```

**Two built-in self-checks, no Tiingo key or network required:**
- `./build/gnc_forecast_live --selftest` — runs the full JSON-parse +
  indicator + EKF + support/resistance pipeline against a literal
  Tiingo-shaped JSON payload baked into the binary. Confirms the build
  and the math both work, independent of any live fetch.
- `./build/gnc_forecast_live --curltest <url>` — hits any URL and prints
  the raw HTTP status/body. Useful for telling apart "no internet from
  this environment" from "something specific to Tiingo/the API key" if
  a real fetch ever fails.

Verified in this sandbox: compiled clean (`g++ -Wall -Wextra`, zero
warnings) against `libcurl4-openssl-dev`/`nlohmann-json3-dev` from Ubuntu
24.04's apt repos; `--selftest` parses 30 literal bars and produces sane
indicator/EKF/support-resistance output; `--curltest` against
`api.github.com` completed a full HTTPS/TLS round-trip (got back a real
HTTP 403 rate-limit response — proving the network/TLS/JSON path works
end-to-end, that specific 403 being GitHub's rate limiting, unrelated to
this code). `api.tiingo.com` itself isn't reachable from this sandbox's
network allowlist, so the live Tiingo fetch specifically is untested
end-to-end — try it from your own environment and let me know if
anything about a real response doesn't match what `--selftest` predicts.

**Not wired up yet, flagged rather than silently skipped:** LLM
news-sentiment fetching (Tiingo News + Claude scoring, mirroring
`fetchTiingoNews`/`scoreNewsSentimentWithClaude` in the `.m` file) isn't
in `interactive_main.cpp`. Nothing in this numeric-only C++ port
consumes a sentiment feature today (that's a BiLSTM input in MATLAB, and
the BiLSTM itself isn't ported — see below), so adding the fetch alone
wouldn't feed anything yet. Say the word if you want it added anyway
(e.g., just to display alongside the other output) — same `libcurl` +
`ANTHROPIC_API_KEY`-from-environment pattern as the MATLAB side.

## What's deliberately NOT ported here, and why

- **Tiingo News fetch + Claude sentiment scoring** (`fetchTiingoNews`,
  `scoreNewsSentimentWithClaude` in the `.m` file) — still not ported (see
  the live-mode section above for why). Tiingo *price* ingestion, however,
  **is** now covered by `gnc_forecast_live`/`interactive_main.cpp` above,
  via `libcurl` + `nlohmann/json` — that part turned out to be a
  reasonable, self-contained rewrite once isolated from the sentiment/
  news side, which still needs the same treatment if you want it.
- **`readtable`/`timetable`/`retime`/`datetime` parsing** — MATLAB-only data
  containers; replaced here with a small hand-rolled CSV reader.
- **`trainNetwork` / `bilstmLayer` / ensemble training** — cannot be
  code-generated by MATLAB Coder under any circumstances; training has to
  stay in MATLAB (or move to PyTorch/TensorFlow if you want a non-MATLAB
  training path). *Inference* of an already-trained network CAN be
  code-generated via MATLAB Coder's Deep Learning Toolbox support
  (`codegen` targeting a `dlnetwork`, backed by MKL-DNN/ARM-CL/TensorRT
  depending on target) — but that's a separate `codegen` invocation on the
  trained network object, not something that comes out of porting this
  `.m` file directly, and it pulls in that backend library as a runtime
  dependency rather than producing dependency-free C++.
- **`figure`/`subplot`/`yline`/`legend`/`uitable`** — plotting/UI, not
  codegen-able and not meaningful outside MATLAB; if you want a native
  chart from the C++ side, options are exporting to CSV and plotting
  elsewhere, or a C++ plotting lib (matplotlib-cpp, Qt Charts, etc.) — again
  a rewrite, not a port.

## If you want the REST of the numeric parts auto-generated too

Everything in the `.m` file's Parts 2–3 (technical extractors + EKF) is
plain array math and was straightforward to hand-port, as above. If you'd
rather have MATLAB Coder generate those same sections directly from your
`.m` source (so the generated code and the hand-port here can be
cross-checked against each other), the shape would be:

```matlab
% coder-compatible entry-point function wrapping just Parts 2-3,
% taking plain double arrays in/out (no timetable/datetime/table types)
function [ekfPrice, ekfVel, ekfResidual, rsi, macd, sig, atr, pvol] = ...
    forecastCoreEntry(closeArr, highArr, lowArr, volArr, lookbackRangeDays)
    ...
end
```
```matlab
codegen forecastCoreEntry -config coder.config('lib') -args ...
    {zeros(0,1), zeros(0,1), zeros(0,1), zeros(0,1), 0}
```

That gives you MATLAB-generated `.c`/`.h` files you can diff against the
hand-port here — useful validation either way. I don't have MATLAB/MATLAB
Coder available in this sandbox to run `codegen` myself, so I can't produce
that output directly, but the entry-point function above is a direct,
ready-to-use starting point if you want to run it on your PSU MATLAB
license.
